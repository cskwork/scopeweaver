# patched Norma SDK (a separate Go module)
(cd third_party/norma && go test ./... -count=1)

