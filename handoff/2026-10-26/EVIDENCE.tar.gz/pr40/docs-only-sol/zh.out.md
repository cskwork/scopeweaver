Updated:
- `CONTRIBUTING.zh-Hans.md`
- `CONTRIBUTING.zh-Hant.md`
- `docs/zh-Hans/PROVENANCE.md`
- `docs/zh-Hant/PROVENANCE.md`
- `docs/zh-Hans/VERIFICATION.md`
- `docs/zh-Hant/VERIFICATION.md`

Checks passed:
- `python3 /private/tmp/pr40-zh-docs-check.py`: old text preserved; source structure, code fences, identifiers, numbers and URLs retained; all 78 local links/fragments resolve.
- `git diff --check`

Stopped sections: none. No known slice issues. Coordinator review remains pending; no runtime tests or release-readiness claim.