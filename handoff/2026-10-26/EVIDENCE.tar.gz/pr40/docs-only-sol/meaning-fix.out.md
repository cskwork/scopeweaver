Changed only five identified sentences:

- `docs/zh-Hans/VERIFICATION.md`: summary **size** limit; count-based eligibility adjustment applies across all context windows.
- `docs/zh-Hant/VERIFICATION.md`: same corrections.
- `docs/ja/VERIFICATION.md`: summary **size** upper bound.

All other bytes in these files preserved. `git diff --check` passed (exit 0).

Document checks and independent re-review remain with the coordinator. No native-speaker or final-readiness claim.