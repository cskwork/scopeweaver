Updated only:

- `CONTRIBUTING.ja.md`
- `docs/ja/PROVENANCE.md`
- `docs/ja/VERIFICATION.md`
- `CONTRIBUTING.es.md`
- `docs/es/PROVENANCE.md`
- `docs/es/VERIFICATION.md`

Checks passed:

- `python3 /tmp/pr40-check-ja-es-docs.py`: literals, numbers, sections, paragraphs, table rows, code fences, external URLs, anchors and 22 new local links.
- Byte-level comparison: all pre-existing content preserved.
- `git diff --check`: exit 0.

Stopped sections/open issues: none. Coordinator review and acceptance remain pending. No build, runtime tests, commit, publication or release-readiness claim.