"""Check only this documentation slice; never execute commands from documents."""
from collections import Counter
from difflib import SequenceMatcher
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

SCRATCH = Path(__file__).resolve().parent
ROOT = SCRATCH.parents[3]
LANGS = ("zh-Hans", "zh-Hant", "ja", "es")
OWNED = [p for lang in LANGS for p in (
    f"CONTRIBUTING.{lang}.md", f"docs/{lang}/PROVENANCE.md", f"docs/{lang}/VERIFICATION.md")]
failures = []
results = []


def links(text):
    return re.findall(r"\[[^\]\n]*\]\(([^\s)]+)\)", text)


def fences(text):
    result, active, body = [], None, []
    for line in text.splitlines():
        if active:
            if line.startswith(active):
                result.append("\n".join(body))
                active, body = None, []
            else:
                body.append(line)
        elif line.startswith("```") or line.startswith("~~~"):
            active = line[:3]
    if active:
        failures.append("unclosed code fence")
    return result


def anchors(path):
    text = path.read_text()
    explicit = re.findall(r'<a\s+(?:id|name)=[\"\']([^\"\']+)', text)
    result = set(explicit)
    seen = Counter()
    for heading in re.findall(r"^#{1,6}\s+(.+)$", text, flags=re.M):
        slug = re.sub(r"[^\w\- ]", "", heading.lower()).replace(" ", "-")
        index = seen[slug]
        seen[slug] += 1
        result.add(slug + (f"-{index}" if index else ""))
    return result, [a for a, count in Counter(explicit).items() if count > 1]


def literal_check(source, added, label):
    # Commands/identifiers/hashes in backticks must survive byte-for-byte.
    expected = Counter(re.findall(r"(?<!`)`([^`\n]+)`(?!`)", source))
    actual = Counter(re.findall(r"(?<!`)`([^`\n]+)`(?!`)", added))
    missing = expected - actual
    if missing:
        failures.append(f"{label}: missing inline literals {dict(missing)}")
    numeric = r"\d+(?:[,.:/-]\d+)*(?:K|M)?"
    missing_numbers = Counter(re.findall(numeric, source)) - Counter(re.findall(numeric, added))
    if missing_numbers:
        failures.append(f"{label}: numeric-token omissions {dict(missing_numbers)}")
    for code in fences(source):
        if code not in fences(added):
            failures.append(f"{label}: source code fence changed or absent")
    for url in links(source):
        if urlsplit(url).scheme in ("http", "https") and url not in links(added):
            failures.append(f"{label}: external URL missing: {url}")


before = json.loads((SCRATCH / "before-sha256.json").read_text())
for path, digest in before.items():
    if path in OWNED:
        continue
    current = ROOT / path
    if not current.is_file() or hashlib.sha256(current.read_bytes()).hexdigest() != digest:
        failures.append(f"protected tracked file changed: {path}")

for path in OWNED:
    old = (SCRATCH / "before" / path).read_text()
    new = (ROOT / path).read_text()
    old_lines, new_lines = old.splitlines(), new.splitlines()
    additions = []
    removed = []
    for kind, i, j, x, y in SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_opcodes():
        if kind in ("insert", "replace"):
            additions.extend(new_lines[x:y])
        if kind in ("delete", "replace"):
            removed.extend(line for line in old_lines[i:j] if line.strip())
    if removed:
        failures.append(f"{path}: pre-existing nonblank lines changed/deleted ({len(removed)})")
    added = "\n".join(additions)
    name = "CONTRIBUTING.md" if path.startswith("CONTRIBUTING") else Path(path).name
    source = (SCRATCH / f"source-{name}").read_text()
    literal_check(source, added, path)
    if name == "CONTRIBUTING.md":
        command = "(cd third_party/norma && go test ./... -count=1)"
        if command not in new:
            failures.append(f"{path}: SDK test command absent")
    else:
        source_headings = re.findall(r"^#{2,3}\s+", source, flags=re.M)
        added_headings = re.findall(r"^#{2,3}\s+", added, flags=re.M)
        if len(source_headings) != len(added_headings):
            failures.append(f"{path}: section count {len(added_headings)} != {len(source_headings)}")
        if len(re.findall(r"^\|", source, flags=re.M)) != len(re.findall(r"^\|", added, flags=re.M)):
            failures.append(f"{path}: evidence table row count differs")
    _, duplicate_ids = anchors(ROOT / path)
    if duplicate_ids:
        failures.append(f"{path}: duplicate explicit anchors: {duplicate_ids}")
    new_links = Counter(links(new)) - Counter(links(old))
    for target in new_links:
        parsed = urlsplit(target)
        if parsed.scheme:
            continue
        dest = (ROOT / path).parent / unquote(parsed.path) if parsed.path else ROOT / path
        if not dest.exists():
            failures.append(f"{path}: broken new local link {target}")
        elif parsed.fragment and dest.suffix == ".md":
            ids, _ = anchors(dest)
            if unquote(parsed.fragment) not in ids:
                failures.append(f"{path}: missing fragment {target}")
    results.append({"path": path, "added_lines": len(additions), "removed_nonblank_lines": len(removed),
                    "new_link_targets_checked": len(new_links)})

diff = subprocess.run(["git", "diff", "--check"], cwd=ROOT, text=True, capture_output=True)
if diff.returncode:
    failures.append("git diff --check: " + diff.stdout + diff.stderr)
report = {"scope": "12 documentation files; protected source hashes, existing prose preservation, literal/code/count/section/table/link checks",
          "files": results, "failures": failures, "exit": int(bool(failures))}
(SCRATCH / "docs-check.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(bool(failures))
