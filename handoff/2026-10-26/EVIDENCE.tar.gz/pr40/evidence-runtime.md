# Runtime evidence: 261025-pr40-review-repair

- Reviewed commit and runtime source: `e9a04b68b57e76875a1ae5ab213562c2b826609d`.
- QA: independent Sol runtime QA delegate.
- Scenario mapping: frontend preparation, chat draft/standard, embedded smoke and dashboard all support **S5**. Agent adapter is additional verification.
- Verdict: changed inspector/context behavior and all requested browser behaviors passed on the explicitly platform-adapted macOS harness. **The canonical unmodified standard and smoke commands failed locally; they are not green.** Native keyboard diagnostics establish the inherited hardcoded Control shortcut as the cause.
- No product source, frontend assets, assertions, or test timeouts were changed by QA. No push or merge occurred.

## Commands and native results

Canonical evidence directory:
`/private/tmp/scopeweaver-pr-repair-runtime-qa/run-e9a04b68b57e-20261024T233149Z`

| Verification | Native exit | Observed |
|---|---:|---|
| Chat draft: `SCOPEWEAVER_CHAT_E2E=1 CHAT_E2E_SUITE=draft go test ./server -run '^TestChatControlsE2E$' -count=1 -timeout 12m -v` | 0 | 5 browser steps passed: segment-zero draft/attachment retention and pending queue/steer admission success/failure. |
| Chat standard: same Go command with `CHAT_E2E_SUITE=standard` | 1 | 50 steps passed, including both changed inspector hydration/binding regressions. 10 paste cases timed out waiting for a paste event; the Go test's existing 9-minute child-browser context then killed the runner at 540.22 seconds. |
| Embedded binary: `go build -tags embedui -o <owned-scratch>/scopeweaver ./cmd/artex` | 0 | Exact committed Go source with existing, fingerprint-matched web/out. |
| `npm --prefix e2e run smoke`, against the embedded binary | 1 | 50 browser steps passed; all 12 document-paste cases failed at the missing paste event. The package's `&&` prevented dashboard execution in this canonical run. |
| `npm --prefix adapters/agent ci` | 0 | Install completed in the disposable archived source. npm reported 4 vulnerabilities: 2 moderate, 2 high. |
| `npm --prefix adapters/agent test` | 0 | 7 tests passed, 0 failed. |
| `npm --prefix adapters/agent run check` | 0 | All existing JavaScript syntax checks passed. |
| `SCOPEWEAVER_ADAPTER_E2E=1 go test ./server -run '^TestAgentAdapterE2E$' -count=1 -v` | 0 | Real HTTP/backend/PostgreSQL adapter E2E passed; its 3 Node tests passed. |

Every command has adjacent `.command.json`, `.log`, `.exit`, and `.result.json` receipts. The canonical aggregate runner exit is 1, retained in `runner.exit`.

## Native macOS failure and bounded harness adaptation

The existing `e2e/chat-paste.mjs` uses `input.press("Control+V")` and `input.press("Control+Z")`. Native macOS requires its Command modifier. The failure occurs before ScopeWeaver receives a native text paste event.

`clipboard-baseline-identity.json` establishes that chat-paste.mjs, chat-controls-runner.mjs and smoke.mjs have identical Git blob IDs on unchanged dev `f354c9201eefe29abbde6b3797f07c59112ee1be` and this reviewed commit. The chat-paste.mjs blob is `5887047619a649c9de2cc17405733c15916f7d2c`.

A real Chromium clipboard diagnostic, with no ScopeWeaver API or intercepted responses, produced:

| Native key | Paste events | Text received |
|---|---:|---|
| Control+V | 0 | empty |
| Meta+V | 1 | isolated-native-clipboard-fixture |
| ControlOrMeta+V | 1 | isolated-native-clipboard-fixture |

Evidence: canonical directory `clipboard-diagnostic.json`, `clipboard-diagnostic.log`, `clipboard-diagnostic.exit` (0), and `clipboard-baseline-identity.json`. This proves the local platform condition; a full baseline application browser run was not repeated.

The coordinator explicitly authorized adapting only those two shortcuts inside a disposable archived QA copy. The adaptation changes them to Playwright `ControlOrMeta+V` and `ControlOrMeta+Z`. Product source/assets and every assertion and timeout remain unchanged. The exact two-line patch and before/after hashes are retained in the platform run's `platform-harness.diff` and `platform-harness.sha256`.

Platform-adapted evidence directory:
`/private/tmp/scopeweaver-pr-repair-runtime-qa/run-e9a04b68b57e-20261024T234850Z-platform`

| Verification | Native exit | Observed |
|---|---:|---|
| Full existing chat standard suite | 0 | **62 browser steps passed**, 0 failed; Go browser test passed in 417.06 seconds. Includes queue/history, context visibility/compaction, inspector initial hydration, replacement binding/late-context rejection, running-tool steering/shared gate, and all 12 native document-paste cases. |
| Embedded binary build | 0 | Exact reviewed product source and fingerprint-matched production frontend. |
| Full existing `npm --prefix e2e run smoke` | 0 | **62 smoke steps passed**, then **14 dashboard scenarios passed**. Includes setup/login/task/settings/chat drafts, Chinese preference restore, language/SSE behavior, existing local Ollama fixtures and failure cases, native document paste, English/Korean Legacy/New token stacks, profile filters and completed task/judge coverage. |
| Aggregate platform runner | 0 | Final frontend fingerprint and clean exact-HEAD checks passed; owned runtime cleaned. |

These are **platform-adapted harness results**, not canonical unmodified CI-suite passes. Recommend a separate source portability fix for the two shortcut strings.

## Prepared frontend evidence reused without rerunning

The independently captured manifest matches all **275 tracked web/e2e files** at preparation, execution and completion. Original preparation fingerprint:
`480e13cacf827d0f9c34b40b7768b695bdc3caafbb7080db83906afb8540dbe0`

Evidence under `/private/tmp/scopeweaver-pr-repair-runtime-qa/`:

- `web-tests.log` / `web-tests.exit`: **72/72 tests passed**, exit 0.
- `web-build.log` / `web-build.exit`: initial static build exported 31/31 pages, then failed with `SecurityFatalError`, exit 1.
- `web-build-retry.log` / `web-build-retry.exit`: unchanged retry exported 31/31 pages and completed, exit 0, with the Next.js upgrade warning retained.
- `web-npm-ci.log`: **2 vulnerabilities (1 high, 1 critical)**; the existing Zod high and Next critical advisories remain unresolved. No dependency change was made.

The retry does not erase the initial build failure or advisory. No frontend tests/build were repeated after the manifest proved the source unchanged.

## Environment, artifacts and cleanup

- Exact SHA checked before execution and after completion; tracked checkout remained clean.
- Existing project Playwright suites were executed from an immutable Git archive of the reviewed commit. All installs/build outputs and temporary harness edits lived in runner-owned scratch.
- Inherited environment was cleared with `env -i`; new HOME, TMPDIR, config and skill directories prevented default credential/config reuse. Provider keys and live provider profiles were not inherited.
- Every scenario used a fresh runner-owned database named `scopeweaver_test_*` or `scopeweaver_adapter_*`.
- PostgreSQL ran on its unique Unix socket directory with `listen_addresses=''`; no TCP listener or existing PostgreSQL service/database was changed.
- The embedded server used a unique loopback port, isolated cwd/data/config/skills, and `-proxy ""`. The existing dashboard suite started and cleaned its own isolated binary copy.
- Initial bootstrap attempt `run-e9a04b68b57e-20261024T233129Z` failed before product tests: macOS PostgreSQL reported a multithreaded postmaster/locale error. Its native pg_ctl exit 1 and PostgreSQL logs remain. Explicit `LC_ALL=C LANG=C` and UTF8 initdb encoding resolved the environment issue; no product code or checks changed.
- Both completed runs stopped their owned app and PostgreSQL processes and deleted disposable data. Platform run `cleanup-verification.json` confirms its runtime path no longer exists and no matching process remains. Canonical runtime cleanup was also checked: no matching process remained.
- Screenshots and read-back evidence remain in each run's `chat-standard-artifacts/` and `smoke-artifacts/`. The adapted dashboard folder contains 46 files, including screenshots, DOM/tooltips, SQL receipts and child server log.
- Visually inspected desktop context inspector, 390-pixel context sheet and English New/All dashboard chart screenshots; content and chart were rendered and readable.

## Limits retained for coordinator

- Full backend suites, race/build/vet, S1-S4/S6 and OpenCode preservation were implementer/coordinator-owned and were not duplicated here.
- Coordinator reports full backend receipts as 2151 passing events, 1 inherited failure and 3 opt-in skips. `TestMainServeFailureRunsShutdown` / scheduler `sql: database is closed` reproduces on unchanged dev in 3/10 runs. This remains an unresolved baseline limitation; this runtime report does not claim a green full backend suite.
- Hosted CI, native Windows and live provider behavior were not exercised.
- No source portability fix, dependency remediation, publication, push or merge is included.

