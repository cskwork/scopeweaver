package db

import (
	"database/sql"
	"fmt"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/stdlib"
)

// TestParseScopeLine covers classification + guardrails without a DB.
func TestParseScopeLine(t *testing.T) {
	cases := []struct {
		in      string
		kind    string
		wantErr bool
	}{
		{"example.com", "domain", false},
		{"https://sub.example.com/path", "domain", false},
		{"1.2.3.4", "ip", false},
		{"10.0.0.0/8", "", true}, // over-broad IPv4 (< /16)
		{"198.51.100.0/24", "cidr", false},
		{"co.uk", "", true}, // bare public suffix
		{"not a host", "", true},
		{"1.2.3.1-1.2.3.9", "", true}, // ranges must be CIDR
	}
	for _, c := range cases {
		r, err := ParseScopeLine(c.in)
		if c.wantErr {
			if err == nil {
				t.Errorf("ParseScopeLine(%q) want error, got %+v", c.in, r)
			}
			continue
		}
		if err != nil {
			t.Errorf("ParseScopeLine(%q) unexpected error: %v", c.in, err)
			continue
		}
		if r.Kind != c.kind {
			t.Errorf("ParseScopeLine(%q) kind=%q want %q", c.in, r.Kind, c.kind)
		}
	}
}

func TestParseAutoScopeLine(t *testing.T) {
	cases := []struct {
		name       string
		input      string
		kind       string
		normalized string
		wantErr    bool
	}{
		{name: "domain", input: "example.com", kind: "domain", normalized: "example.com"},
		{name: "url", input: "https://sub.example.com/path", kind: "domain", normalized: "sub.example.com"},
		{name: "url query", input: "https://example.com/path?source=x", kind: "domain", normalized: "example.com"},
		{name: "url credentials", input: "https://user:__REDACTED_000024__@example.com/path", kind: "domain", normalized: "example.com"},
		{name: "url ip", input: "http://203.0.113.10/path", kind: "ip", normalized: "203.0.113.10/32"},
		{name: "ipv4", input: "203.0.113.10", kind: "ip", normalized: "203.0.113.10/32"},
		{name: "ipv6", input: "2001:db8::10", kind: "ip", normalized: "2001:db8::10/128"},
		{name: "cidr", input: "198.51.100.0/24", kind: "cidr", normalized: "198.51.100.0/24"},
		{name: "icp latin", input: "京 ICP备 123号", kind: "icp", normalized: "京icp备123号"},
		{name: "icp chinese", input: "沪网备案 9988", kind: "icp", normalized: "沪网备案9988"},
		{name: "icp domain", input: "icp.example.com", kind: "domain", normalized: "icp.example.com"},
		{name: "icp url query", input: "https://example.com/path?icp=1", kind: "domain", normalized: "example.com"},
		// ICP numbers contain no dots: descriptions containing domains/versions become keywords,
		// avoiding an ICP rule that could never match.
		{name: "icp with domain text", input: "备案 www.example.com", kind: "keyword", normalized: "备案 www.example.com"},
		{name: "icp with version text", input: "某公司 ICP v1.0", kind: "keyword", normalized: "某公司 icp v1.0"},
		{name: "icp fullwidth dot", input: "备案 例．com", kind: "keyword", normalized: "备案 例．com"},
		{name: "keyword", input: "  ACME   Security  ", kind: "keyword", normalized: "acme security"},
		{name: "colon keyword", input: "ACME: Cloud: Security", kind: "keyword", normalized: "acme: cloud: security"},
		{name: "empty", input: "  ", wantErr: true},
		{name: "invalid cidr", input: "10.0.0.0/not-a-prefix", wantErr: true},
		{name: "invalid ipv4", input: "999.0.0.1", wantErr: true},
		{name: "invalid ipv6", input: "2001:db8::zz", wantErr: true},
		{name: "invalid ipv6 cidr", input: "2001:db8::zz/64", wantErr: true},
		{name: "overbroad cidr", input: "10.0.0.0/8", wantErr: true},
		{name: "bare suffix", input: "co.uk", wantErr: true},
		{name: "empty domain label", input: "foo..example.com", wantErr: true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			rule, err := ParseAutoScopeLine(tc.input)
			if tc.wantErr {
				if err == nil {
					t.Fatalf("ParseAutoScopeLine(%q) = %+v, want error", tc.input, rule)
				}
				return
			}
			if err != nil {
				t.Fatalf("ParseAutoScopeLine(%q): %v", tc.input, err)
			}
			if rule.Kind != tc.kind {
				t.Fatalf("kind=%q want %q", rule.Kind, tc.kind)
			}
			got := rule.Value
			if rule.Kind == "domain" {
				got = rule.Domain
			} else if rule.Kind == "ip" || rule.Kind == "cidr" {
				got = rule.Net
			}
			if got != tc.normalized {
				t.Fatalf("normalized=%q want %q", got, tc.normalized)
			}
		})
	}
}

// TestDomainScopeMatchesSubdomains pins the host-suffix rule in both
// attribution paths: a `domain` entry covers its own name and every name
// under it, never a look-alike that merely ends with the same characters.
func TestDomainScopeMatchesSubdomains(t *testing.T) {
	d, as, cs := testSetup(t)
	defer d.Close()

	stamp := time.Now().UnixNano()
	suffix := uint64(stamp) & 0xffffff
	company, _, err := cs.UpsertCompany(fmt.Sprintf("Suffix Match %d", stamp), "")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { cleanupCompany(d, company) })

	apex := fmt.Sprintf("suffix-%d.example", suffix)
	rules := []ScopeInput{{Kind: "domain", Value: apex}}
	if added, _, invalid, errs := cs.AddScopeInputs(company, rules, "test"); added != len(rules) || invalid != 0 {
		t.Fatalf("AddScopeInputs: added=%d invalid=%d errors=%v", added, invalid, errs)
	}

	assertOwner := func(label string, id int64, want *int64) {
		t.Helper()
		var got *int64
		if err := d.QueryRow(`SELECT company_id FROM assets WHERE id=$1`, id).Scan(&got); err != nil {
			t.Fatal(err)
		}
		switch {
		case want == nil && got != nil:
			t.Fatalf("%s: attributed to %d, want unattributed", label, *got)
		case want != nil && (got == nil || *got != *want):
			t.Fatalf("%s: company=%v want %d", label, got, *want)
		}
	}

	cases := []struct {
		host      string
		attribute bool
	}{
		{apex, true},
		{"www." + apex, true},
		{"a.b." + apex, true},
		{"evil" + apex, false},
	}

	// Insert-time resolution (UpsertSubdomain resolves by the asset's own host).
	inserted := make(map[string]int64, len(cases))
	for _, c := range cases {
		id, err := as.UpsertSubdomain(UpsertSubdomainReq{Domain: c.host})
		if err != nil {
			t.Fatalf("upsert %s: %v", c.host, err)
		}
		inserted[c.host] = id
		want := &company
		if !c.attribute {
			want = nil
		}
		assertOwner("insert-time "+c.host, id, want)
	}

	// The recompute must agree with insert-time resolution.
	if err := cs.RecomputeAttribution(); err != nil {
		t.Fatal(err)
	}
	for _, c := range cases {
		want := &company
		if !c.attribute {
			want = nil
		}
		assertOwner("recomputed "+c.host, inserted[c.host], want)
	}
}

func TestParseHostScopeInput(t *testing.T) {
	cases := []struct {
		name    string
		value   string
		domain  string
		wantErr bool
	}{
		{name: "subdomain", value: "cms.example.no", domain: "cms.example.no"},
		{name: "url with port and path", value: "https://cms.example.no:8443/x", domain: "cms.example.no"},
		{name: "uppercase", value: "CMS.Example.NO", domain: "cms.example.no"},
		{name: "apex", value: "example.no", domain: "example.no"},
		{name: "ipv4", value: "8.8.8.8", wantErr: true},
		{name: "ipv6", value: "2001:db8::10", wantErr: true},
		{name: "bare tld", value: "no", wantErr: true},
		{name: "public suffix", value: "co.uk", wantErr: true},
		{name: "empty", value: "   ", wantErr: true},
		{name: "invalid label", value: "cms..example.no", wantErr: true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			rule, err := ParseScopeInput(ScopeInput{Kind: "host", Value: tc.value})
			if tc.wantErr {
				if err == nil {
					t.Fatalf("ParseScopeInput(host %q) = %+v, want error", tc.value, rule)
				}
				return
			}
			if err != nil {
				t.Fatalf("ParseScopeInput(host %q): %v", tc.value, err)
			}
			if rule.Kind != "host" || rule.Domain != tc.domain {
				t.Fatalf("host %q parsed as kind=%q domain=%q want %q", tc.value, rule.Kind, rule.Domain, tc.domain)
			}
		})
	}

	// An untyped subdomain line stays a domain entry: the textarea is unchanged.
	auto, err := ParseAutoScopeLine("cms.example.no")
	if err != nil {
		t.Fatalf("auto parse: %v", err)
	}
	if auto.Kind != "domain" || auto.Domain != "cms.example.no" {
		t.Fatalf("untyped cms.example.no parsed as %+v, want domain", auto)
	}
}

func TestExplicitCompanyAttributionSurvivesScopeRebuild(t *testing.T) {
	d, as, cs := testSetup(t)
	defer d.Close()

	stamp := time.Now().UnixNano()
	explicitCompany, _, err := cs.UpsertCompany(fmt.Sprintf("Explicit Attribution %d", stamp), "")
	if err != nil {
		t.Fatal(err)
	}
	autoCompany, _, err := cs.UpsertCompany(fmt.Sprintf("Automatic Attribution %d", stamp), "")
	if err != nil {
		t.Fatal(err)
	}
	defer cleanupCompany(d, explicitCompany)
	defer cleanupCompany(d, autoCompany)

	domain := fmt.Sprintf("explicit-%d.invalid", stamp)
	icp := fmt.Sprintf("ICP-%d", stamp)
	network := fmt.Sprintf("2001:db8:%x::/64", uint64(stamp)&0xffff)
	ip := fmt.Sprintf("2001:db8:%x::10", uint64(stamp)&0xffff)

	// A pre-existing row with company_id and no provenance value represents old
	// installations. The schema default conservatively treats it as explicit.
	var assetID int64
	if err := d.QueryRow(`INSERT INTO assets(type,domain,root_domain,company_id)
		VALUES ('root_domain',$1,$1,$2) RETURNING id`, domain, explicitCompany).Scan(&assetID); err != nil {
		t.Fatal(err)
	}
	defer deleteAsset(d, assetID)
	appID, err := as.UpsertApp(UpsertAppReq{
		Name: fmt.Sprintf("explicit-app-%d", stamp), ICP: icp, CompanyID: &explicitCompany,
	})
	if err != nil {
		t.Fatal(err)
	}
	defer deleteAsset(d, appID)
	autoAssetID, err := as.UpsertIP(UpsertIPReq{IP: ip})
	if err != nil {
		t.Fatal(err)
	}
	defer deleteAsset(d, autoAssetID)

	rules := []ScopeInput{
		{Kind: "domain", Value: domain},
		{Kind: "icp", Value: icp},
		{Kind: "cidr", Value: network},
	}
	if added, _, invalid, errs := cs.AddScopeInputs(autoCompany, rules, "test"); added != len(rules) || invalid != 0 {
		t.Fatalf("AddScopeInputs: added=%d invalid=%d errors=%v", added, invalid, errs)
	}

	assertCompany := func(id, want int64, source string) {
		t.Helper()
		var got *int64
		var gotSource string
		if err := d.QueryRow(`SELECT company_id,company_source FROM assets WHERE id=$1`, id).Scan(&got, &gotSource); err != nil {
			t.Fatal(err)
		}
		if got == nil || *got != want || gotSource != source {
			t.Fatalf("asset %d company=%v source=%q, want %d/%q", id, got, gotSource, want, source)
		}
	}
	assertCompany(assetID, explicitCompany, "explicit")
	assertCompany(appID, explicitCompany, "explicit")
	assertCompany(autoAssetID, autoCompany, "scope")

	// Replacing every matching rule detaches only the automatically-owned row.
	if _, invalid, errs := cs.UpdateScopeInputs(autoCompany, []ScopeInput{
		{Kind: "domain", Value: fmt.Sprintf("replacement-%d.invalid", stamp)},
	}, "test"); invalid != 0 || len(errs) != 0 {
		t.Fatalf("UpdateScopeInputs: invalid=%d errors=%v", invalid, errs)
	}
	assertCompany(assetID, explicitCompany, "explicit")
	assertCompany(appID, explicitCompany, "explicit")
	var autoCompanyID *int64
	var autoSource string
	if err := d.QueryRow(`SELECT company_id,company_source FROM assets WHERE id=$1`, autoAssetID).Scan(&autoCompanyID, &autoSource); err != nil {
		t.Fatal(err)
	}
	if autoCompanyID != nil || autoSource != "scope" {
		t.Fatalf("automatic asset was not detached: company=%v source=%q", autoCompanyID, autoSource)
	}

	if err := cs.RecomputeAttribution(); err != nil {
		t.Fatal(err)
	}
	assertCompany(assetID, explicitCompany, "explicit")
	assertCompany(appID, explicitCompany, "explicit")

	// Deleting the explicitly selected company detaches through the FK, then the
	// transactional rebuild may adopt the assets into a still-valid scope.
	if _, invalid, errs := cs.UpdateScopeInputs(autoCompany, []ScopeInput{
		{Kind: "domain", Value: domain},
		{Kind: "icp", Value: icp},
	}, "test"); invalid != 0 || len(errs) != 0 {
		t.Fatalf("restore fallback scope: invalid=%d errors=%v", invalid, errs)
	}
	if err := cs.DeleteCompany(explicitCompany); err != nil {
		t.Fatal(err)
	}
	assertCompany(assetID, autoCompany, "scope")
	assertCompany(appID, autoCompany, "scope")
}

func TestParseStructuredCompanyScope(t *testing.T) {
	icp, err := ParseScopeInput(ScopeInput{Kind: "ICP", Value: " 京ICP 备 123号-1\t"})
	if err != nil {
		t.Fatalf("parse ICP: %v", err)
	}
	if icp.Kind != "icp" || icp.Value != "京icp备123号-1" {
		t.Fatalf("unexpected normalized ICP: %+v", icp)
	}
	keyword, err := ParseScopeInput(ScopeInput{Kind: "keyword", Value: "  ACME   Security  "})
	if err != nil {
		t.Fatalf("parse keyword: %v", err)
	}
	if keyword.Value != "acme security" {
		t.Fatalf("unexpected normalized keyword: %+v", keyword)
	}
	if _, err := ParseScopeInput(ScopeInput{Kind: "ip", Value: "example.com"}); err == nil {
		t.Fatal("typed IP accepted a domain")
	}
}

func TestCompanyICPAttribution(t *testing.T) {
	d, err := Open(testDSN(t))
	if err != nil {
		t.Skipf("postgres unavailable (%v) — skipping", err)
	}
	// Close the connection through t.Cleanup and register it BEFORE data cleanup: cleanup is LIFO,
	// so the first-registered close runs last and data cleanup still has a live connection.
	// Previously defer d.Close() ran as the function returned, before t.Cleanup,
	// causing cleanup on a closed connection while _, _ = discarded errors.
	// Assets and companies remained permanently. This did not fail immediately, but this test uses
	// MAX(companies.id)+1 as a synthetic TaskID (see suffix below).
	// If that value collided with another test's task ID, exact asset-count assertions
	// in that test failed unpredictably and were expensive to diagnose.
	t.Cleanup(func() { d.Close() })

	var suffix int64
	if err := d.QueryRow(`SELECT COALESCE(MAX(id),0)+1 FROM companies`).Scan(&suffix); err != nil {
		t.Fatal(err)
	}
	cs := d.Companies()
	as := d.Assets()
	companyID, _, err := cs.UpsertCompany(fmt.Sprintf("ICP Scope Co %d", suffix), "")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		// Do not swallow cleanup errors: failures contaminate later tests and must surface in this run.
		if _, err := d.Exec(`DELETE FROM assets WHERE task_ids @> ARRAY[$1]::bigint[]`, suffix); err != nil {
			t.Errorf("Clean up test assets: %v", err)
		}
		if _, err := d.Exec(`DELETE FROM companies WHERE id=$1`, companyID); err != nil {
			t.Errorf("Clean up test companies: %v", err)
		}
	})

	// A keyword can guide an Agent, but must never claim an asset by its name.
	added, _, invalid, errs := cs.AddScopeInputs(companyID, []ScopeInput{
		{Kind: "icp", Value: "京 ICP备 998877号"},
		{Kind: "keyword", Value: "ICP Scope"},
	}, "unit test")
	if added != 2 || invalid != 0 || len(errs) != 0 {
		t.Fatalf("add structured scope: added=%d invalid=%d errors=%v", added, invalid, errs)
	}

	rootID, err := as.UpsertRootDomain(UpsertRootDomainReq{
		Domain: fmt.Sprintf("icp-scope-%d.example", suffix), ICP: "京icp备998877号", TaskID: suffix,
	})
	if err != nil {
		t.Fatal(err)
	}
	appID, err := as.UpsertApp(UpsertAppReq{
		Name: fmt.Sprintf("ICP Scope Keyword Only %d", suffix), TaskID: suffix,
	})
	if err != nil {
		t.Fatal(err)
	}
	icpAppID, err := as.UpsertApp(UpsertAppReq{
		Name: fmt.Sprintf("ICP Matched App %d", suffix), ICP: " 京 ICP备 998877号 ", TaskID: suffix,
	})
	if err != nil {
		t.Fatal(err)
	}

	assertCompany := func(assetID int64, want *int64) {
		t.Helper()
		var got *int64
		if err := d.QueryRow(`SELECT company_id FROM assets WHERE id=$1`, assetID).Scan(&got); err != nil {
			t.Fatal(err)
		}
		if want == nil && got != nil {
			t.Fatalf("asset %d attributed by keyword: %d", assetID, *got)
		}
		if want != nil && (got == nil || *got != *want) {
			t.Fatalf("asset %d company=%v want %d", assetID, got, *want)
		}
	}
	assertCompany(rootID, &companyID)
	assertCompany(appID, nil)
	assertCompany(icpAppID, &companyID)
}

// TestCompanyScopeAttribution exercises the full loop against dev PG: create
// company (unique name), add scope, and verify auto-attribution at insert time,
// backfill of a pre-existing asset, CIDR + domain-suffix matching, and that
// out-of-scope assets stay unattributed.
func TestCompanyScopeAttribution(t *testing.T) {
	d, err := Open(testDSN(t))
	if err != nil {
		t.Skipf("postgres unavailable (%v) — skipping", err)
	}
	as := d.Assets()
	cs := d.Companies()

	var startMax int64
	if err := d.QueryRow(`SELECT COALESCE(MAX(id),0) FROM assets`).Scan(&startMax); err != nil {
		d.Close()
		t.Fatalf("startMax: %v", err)
	}
	t.Cleanup(func() {
		_, _ = d.Exec(`DELETE FROM assets WHERE id > $1`, startMax)
		d.Close()
	})

	uniq := startMax + 1
	root := fmt.Sprintf("scopetest%d.com", uniq)
	sub := "api." + root
	ipIn := "198.51.100.9"
	ipOut := "203.0.113.9"
	outDomain := fmt.Sprintf("other%d.net", uniq)

	cid, _, err := cs.UpsertCompany(fmt.Sprintf("ScopeCo %d", uniq), "")
	if err != nil {
		t.Fatalf("UpsertCompany: %v", err)
	}

	// a pre-existing asset (inserted BEFORE any scope) — must be back-filled.
	preID, err := as.UpsertSubdomain(UpsertSubdomainReq{Domain: sub})
	if err != nil {
		t.Fatalf("pre upsert: %v", err)
	}
	var preCompanyID *int64
	d.QueryRow(`SELECT company_id FROM assets WHERE id = $1`, preID).Scan(&preCompanyID)
	if preCompanyID != nil {
		t.Fatalf("pre-scope asset should be unattributed, got %v", *preCompanyID)
	}

	cs.AddScope(cid, []string{root, "198.51.100.0/24"}, "unit test")

	mustCid := func(id int64, want int64, label string) {
		var cID *int64
		d.QueryRow(`SELECT company_id FROM assets WHERE id = $1`, id).Scan(&cID)
		if cID == nil {
			t.Fatalf("%s company_id = nil, want %d", label, want)
		}
		if *cID != want {
			t.Fatalf("%s company_id = %d, want %d", label, *cID, want)
		}
	}
	mustNil := func(id int64, label string) {
		var cID *int64
		d.QueryRow(`SELECT company_id FROM assets WHERE id = $1`, id).Scan(&cID)
		if cID != nil {
			t.Fatalf("%s should be unattributed, got %d", label, *cID)
		}
	}

	// backfill attributed the pre-existing subdomain (domain suffix match).
	mustCid(preID, cid, "pre-existing subdomain (backfill)")

	// insert-time attribution: ip in CIDR, another subdomain.
	ipInID, err := as.UpsertIP(UpsertIPReq{IP: ipIn})
	if err != nil {
		t.Fatalf("UpsertIP in: %v", err)
	}
	mustCid(ipInID, cid, "in-CIDR ip (insert-time)")

	sub2ID, err := as.UpsertSubdomain(UpsertSubdomainReq{Domain: "www." + root})
	if err != nil {
		t.Fatalf("UpsertSubdomain: %v", err)
	}
	mustCid(sub2ID, cid, "new subdomain (insert-time)")

	// out of scope stays unattributed.
	outID, err := as.UpsertRootDomain(UpsertRootDomainReq{Domain: outDomain})
	if err != nil {
		t.Fatalf("UpsertRootDomain out: %v", err)
	}
	mustNil(outID, "out-of-scope domain")

	ipOutID, err := as.UpsertIP(UpsertIPReq{IP: ipOut})
	if err != nil {
		t.Fatalf("UpsertIP out: %v", err)
	}
	mustNil(ipOutID, "out-of-CIDR ip")

	// A host no domain entry covers still falls through to the IP rule.
	svcID, err := as.UpsertHTTPService(UpsertHTTPServiceReq{URL: "https://web." + outDomain + "/", IP: ipIn})
	if err != nil {
		t.Fatalf("UpsertHTTPService: %v", err)
	}
	mustCid(svcID, cid, "out-of-scope host on in-CIDR ip (insert-time)")
}

// TestHostScopeAttribution pins the `host` entry rule in both attribution
// paths: a host entry claims exactly its own name, never anything under it,
// and wins over a broader `domain` entry owned by another company.
func TestHostScopeAttribution(t *testing.T) {
	d, as, cs := testSetup(t)
	defer d.Close()

	stamp := time.Now().UnixNano()
	suffix := uint64(stamp) & 0xffffff
	domainCompany, _, err := cs.UpsertCompany(fmt.Sprintf("Host Scope Domain %d", stamp), "")
	if err != nil {
		t.Fatal(err)
	}
	hostCompany, _, err := cs.UpsertCompany(fmt.Sprintf("Host Scope Host %d", stamp), "")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		cleanupCompany(d, domainCompany)
		cleanupCompany(d, hostCompany)
	})

	apex := fmt.Sprintf("hostscope-%d.example", suffix)
	cms := "cms." + apex
	if added, _, invalid, errs := cs.AddScopeInputs(domainCompany, []ScopeInput{
		{Kind: "domain", Value: apex},
	}, "test"); added != 1 || invalid != 0 {
		t.Fatalf("add domain scope: added=%d invalid=%d errors=%v", added, invalid, errs)
	}
	if added, _, invalid, errs := cs.AddScopeInputs(hostCompany, []ScopeInput{
		{Kind: "host", Value: cms},
	}, "test"); added != 1 || invalid != 0 {
		t.Fatalf("add host scope: added=%d invalid=%d errors=%v", added, invalid, errs)
	}

	assertOwner := func(label string, id int64, want int64) {
		t.Helper()
		var got *int64
		if err := d.QueryRow(`SELECT company_id FROM assets WHERE id=$1`, id).Scan(&got); err != nil {
			t.Fatal(err)
		}
		if got == nil || *got != want {
			t.Fatalf("%s: company=%v want %d", label, got, want)
		}
	}

	// Insert-time resolution: the host entry wins over the covering domain entry.
	apexID, err := as.UpsertSubdomain(UpsertSubdomainReq{Domain: apex})
	if err != nil {
		t.Fatalf("upsert apex: %v", err)
	}
	assertOwner("insert-time apex", apexID, domainCompany)

	cmsID, err := as.UpsertSubdomain(UpsertSubdomainReq{Domain: cms})
	if err != nil {
		t.Fatalf("upsert cms: %v", err)
	}
	assertOwner("insert-time host entry", cmsID, hostCompany)

	childID, err := as.UpsertSubdomain(UpsertSubdomainReq{Domain: "x." + cms})
	if err != nil {
		t.Fatalf("upsert child of host: %v", err)
	}
	assertOwner("insert-time child of host entry", childID, domainCompany)

	wwwID, err := as.UpsertSubdomain(UpsertSubdomainReq{Domain: "www." + apex})
	if err != nil {
		t.Fatalf("upsert www: %v", err)
	}
	assertOwner("insert-time www", wwwID, domainCompany)

	// The recompute must agree with insert-time resolution.
	if err := cs.RecomputeAttribution(); err != nil {
		t.Fatal(err)
	}
	assertOwner("recomputed apex", apexID, domainCompany)
	assertOwner("recomputed host entry", cmsID, hostCompany)
	assertOwner("recomputed child of host entry", childID, domainCompany)
	assertOwner("recomputed www", wwwID, domainCompany)
}

// TestHostScopeUpgrade accepts a host row after Open on a database created with
// the previous kind/payload constraints: the idempotent ALTER block widens them.
func TestHostScopeUpgrade(t *testing.T) {
	cfg, err := pgx.ParseConfig(testDSN(t))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.HasPrefix(cfg.Database, "scopeweaver_test_") {
		t.Fatal("upgrade requires a disposable scopeweaver_test_* database")
	}
	admin := stdlib.OpenDB(*cfg)
	t.Cleanup(func() { admin.Close() })
	schema := pgx.Identifier{"host_upgrade_" + strings.ReplaceAll(chatID(), "-", "")}.Sanitize()
	if _, err := admin.ExecContext(t.Context(), "CREATE SCHEMA "+schema); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if _, err := admin.Exec("DROP SCHEMA " + schema + " CASCADE"); err != nil {
			t.Error(err)
		}
	})
	cfg.RuntimeParams["search_path"] = schema
	old := stdlib.OpenDB(*cfg)
	baseline, err := os.ReadFile("testdata/chat_upgrade_6366429.sql")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := old.ExecContext(t.Context(), string(baseline)); err != nil {
		t.Fatalf("baseline schema: %v", err)
	}
	var company int64
	if err := old.QueryRow(`INSERT INTO companies(name,nkey) VALUES('Host Upgrade Co','host-upgrade-co') RETURNING id`).Scan(&company); err != nil {
		t.Fatal(err)
	}
	// The pre-host constraint must still reject a host row.
	if _, err := old.Exec(`INSERT INTO company_scope(company_id,kind,domain,raw) VALUES($1,'host','cms.example.invalid','cms.example.invalid')`, company); err == nil {
		old.Close()
		t.Fatal("old constraint accepted a host row")
	}
	if err := old.Close(); err != nil {
		t.Fatal(err)
	}

	d := &DB{stdlib.OpenDB(*cfg)}
	t.Cleanup(func() { d.Close() })
	if err := withSchemaMigrationLock(t.Context(), d.DB, func(conn *sql.Conn) error {
		return applySchemaWithRetry(t.Context(), conn, time.Sleep)
	}); err != nil {
		t.Fatalf("upgrade: %v", err)
	}
	if added, _, invalid, errs := d.Companies().AddScopeInputs(company, []ScopeInput{
		{Kind: "host", Value: "cms.example.invalid"},
	}, "upgrade test"); added != 1 || invalid != 0 {
		t.Fatalf("host row after upgrade: added=%d invalid=%d errors=%v", added, invalid, errs)
	}
	var stored string
	if err := d.QueryRow(`SELECT kind||'='||domain FROM company_scope WHERE company_id=$1 AND kind='host'`, company).Scan(&stored); err != nil {
		t.Fatal(err)
	}
	if stored != "host=cms.example.invalid" {
		t.Fatalf("stored host entry = %q", stored)
	}
}
