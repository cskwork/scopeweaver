# Evidence: 261025-pr40-review-repair

- Commit: e9a04b68b57e76875a1ae5ab213562c2b826609d
- QA: independent source reviewer and /root/qa_pr40_runtime; coordinator verified Git, logs and composition.

## Checks
- build: `go build ./...` and `go build -tags embedui ... ./cmd/artex` → PASS; logs/final-build.log and runtime receipts.
- test: CI-style isolated database per package, `go test -p 1 <package> -count=1 -json` → **FAIL: 2151 passing test/subtest events, 1 inherited failure, 3 opt-in skips**; logs/final-summary.json and final-package-*.jsonl.
- lint: `go vet ./...` and `git diff --check` → PASS; logs/final-vet.log and logs/final-diff-check.log.
- frontend: `npm test` → 72/72 PASS. Static build first exported 31 pages then exited 1 on the existing Next.js advisory; unchanged retry exited 0. Both results retained in /private/tmp/scopeweaver-pr-repair-runtime-qa/.
- e2e: canonical draft PASS (5 steps); canonical standard and embedded smoke FAIL on inherited macOS Control shortcuts. Disposable native-shortcut adaptation: standard 62/62, smoke 62/62, dashboard 14/14 PASS. These are **not** unmodified canonical-suite passes; evidence-runtime.md gives exact commands and receipts.
- adapter: 7 unit tests, syntax checks and real-backend E2E with 3 Node tests PASS.
- The full package run's three opt-in skips were TestAgentAdapterE2E, TestChatControlsE2E, and TestLiveContextReview. Adapter and chat suites were subsequently enabled and exercised separately; live-provider context review remains unrun.
- dependency audits: existing frontend advisories (1 critical, 1 high) and adapter install advisories (2 high, 2 moderate) remain. No lockfile/dependency changes.

## Results
| ID | Result | Cause | Observed | Log |
|---|---|---|---|---|
| S1 | PASS | — | Four intended commits rebuilt on f354c92; full agent and locale packages pass; exact 1987-key three-language completeness passes. | logs/final-summary.json |
| S2 | PASS | — | Original helper fails SQLSTATE42501; NOCREATEDB URL and keyword fixtures pass with owned schemas, pooled isolation, parent sentinel preservation and cleanup. | logs/green.log |
| S3 | PASS | — | Current OpenCode config/environment/session/header and host-scope regressions pass; provider and production schema files remain unchanged from dev. | logs/final-summary.json |
| S4 | FAIL | code | Full suite retains TestMainServeFailureRunsShutdown scheduler write after database close. Same failure reproduces 3/10 on untouched dev; build, vet and whitespace pass. This inherited failure is outside approved repair scope. | logs/final-package-3.jsonl |
| S6 | PASS | — | Both terminal-tool writes and planner snapshot synchronized. Repeated race checks: 174 agent + 204 server passing events, zero failures/skips or DATA RACE, authentic receipts retained. | logs/race_green.log |
| S5 | PASS | — | Requested browser behaviors pass on the exact product commit with native macOS shortcuts in a disposable harness; 62 standard + 62 smoke + 14 dashboard. Canonical unmodified Mac suites still FAIL and are separately retained. Frontend 72/72 and adapter checks pass. | evidence-runtime.md |

S5 establishes product behavior using the host's real native shortcuts. It does not convert the canonical CI command failures into passes. S4 remains an actual failure, so overall verification is not green and no merge-readiness claim is made.

## Bug proof

Before repair at f8cb518, the new fixtures connect as the test owner but issue `CREATE DATABASE`. A `NOCREATEDB` owner can create tables/schemas in its existing disposable database, but cannot create a second database. Four affected leaf cases fail with SQLSTATE42501 (`logs/red.log`); the new isolation regression fails for the same reason (`logs/isolation_red.log`).

As-is:
```go
admin, err := pgx.Connect(ctx, parentDSN)
// Connection failure handled before executing SQL.
admin.Exec(ctx, "CREATE DATABASE "+identifier)
```

To-be, in server/tools_stock_schema_test.go:289:
```go
admin, err := pgx.Connect(ctx, parentDSN)
// Connects to the same guarded disposable database.
admin.Exec(ctx, "CREATE SCHEMA "+identifier)
// Every fixture pool connection selects only the newly owned schema.
query.Set("search_path", name)
```

The connection retains the test owner's credentials. Schema creation uses privileges already held by that database owner. The DSN preserves its database and other options; its restricted search_path prevents fallback to public fixtures. Cleanup closes stores and drops only the schema whose creation succeeded. Schema deletion does not claim the old child-database helper's idle-client leak detection.

One real persisted test row is `value = 'parent unchanged'` in the unique parent sentinel table. The regression reads three separately held pool connections: the parent marker is invisible from each owned schema, and the parent row remains `'parent unchanged'` after cleanup. This is controlled test data, not a production record. Counterexample: a CREATEDB-capable role passed the original helper, which is why that route alone missed the default-role regression.

The race RED in `logs/focused_race.log` occurs when a paused stream returns while the genuine prove_goal handler still writes the result. Previously the writer assigned `GoalMet` and `Reason` directly and Planner returned both fields directly. Now both actual terminal writers call:
```go
func (t *ToolSet) markGoalMet(reason string) {
    t.goalMu.Lock()
    defer t.goalMu.Unlock()
    t.GoalMet, t.Reason = true, reason
}
```
Planner calls `goalResult()`, which reads the pair under the same private mutex. Locking serializes the two field accesses; releasing immediately preserves SQL, terminal-gate and cancellation ordering. Exported compatibility fields remain unchanged. Counterexample: an early parent pause may legitimately produce a paused receipt rather than completion; passing race checks must preserve that result, which the S18 parent_pause assertions verify. GREEN is three repeated race runs in `logs/race_green.log`.

## Composition and remaining limits
- Git merge-tree of this commit and PR46 local commit 42183237572c1def559bff9ccd834498c9fb2369 exits 0; combined tree e10d12c3f6c79743bfc8dc02c8d17877785a85aa differs from this tested runtime only in .github/workflows/ci.yml.
- Current remote dev was rechecked as f354c9201eefe29abbde6b3797f07c59112ee1be. The original remote PR heads remain unchanged/conflicted with no checks; no remote delivery occurred.
- Inherited startup shutdown failure remains; `logs/baseline_serve.log` reproduces it in 3/10 unchanged-dev runs.
- Canonical Mac clipboard harness remains nonportable. Only the disposable test copy was adapted; source portability correction is a separate recommendation.
- Existing frontend and adapter dependency advisories remain. Initial failed build and successful retry are both retained.
- Exact-head hosted CI, native Windows and live provider behavior remain unverified.
- Owned PostgreSQL/app processes and disposable data were cleaned. See evidence-runtime.md for cleanup receipts and screenshots.

## Delivery
- Target: local
- Delivered: e9a04b68b57e76875a1ae5ab213562c2b826609d
- Location: /Users/danny/Documents/Git/scopeweaver-worktrees/pr40-review-repair, branch fix/pr40-review-repair.
- Checked with: `git rev-parse HEAD`, `git status --short`, `git merge-base --is-ancestor f354c92 HEAD`, `git merge-tree --write-tree HEAD 4218323`.
- Output: exact reviewed HEAD; clean tracked tree; approved dev ancestor; merge simulation exit 0.
- Authorized: yes — user answered "yes" to the scoped local fix-and-verification proposal. No push/merge authorized or performed.
- Policy: unchanged; paired English/Korean verification docs describe the new fixture contract and inherited failure.
- Status: local reviewable repair prepared; verification gate remains failed at S4. Do not mark shipped/merge-ready.
- SDLC score: 5/6 (83.3%) verification scenarios; must 5/6; FAIL S4(code); route build. The required source change for the inherited scheduler defect lies outside the approved repair scope and was not made.
