# Evidence: 261025-pr40-review-repair

## Candidate
- Branch: fix/pr40-review-repair, base f354c9201eefe29abbde6b3797f07c59112ee1be.
- Commit: e9a04b68b57e76875a1ae5ab213562c2b826609d
- No push, merge, PR comments or live-provider calls.

## Scenarios
| ID | Result | Evidence |
|---|---|---|
| S1 | PASS | server final package log: TestAllProductionPackagesHaveRawShippedTranslations passes with exact1987 assertion; agent616/locale19 pass. Four intended cherry-picks only; provider/schema files unchanged from dev. |
| S2 | PASS | logs/red.log and isolation_red.log reproduce42501; green.log62 events, keyword.log60 events, both count2; race_green.log repeats3 and final server587 pass. Owning role NOCREATEDB, Unix socket only; pooled connections constrained, parent sentinel retained, owned schema removed. |
| S3 | PASS | logs/final-summary.json detailed OpenCode config/env/header and host-scope successes; race_green.log current defaults/session regressions pass. |
| S4 | FAIL (inherited) | final-package-*.jsonl:2151 pass,1 fail,3 opt-in skips; cmd/artex TestMainServeFailureRunsShutdown remains, reproduced3/10 untouched-dev baseline_serve.log. Full server/db/agent pass. final-build.log, final-vet.log, final-diff-check.log pass. Original parallel failure retained all_go.log. |
| S5 | PENDING | Coordinator owns exact-candidate frontend/browser/adapter; source frontend already reported72 pass and build retry, separate evidence. |
| S6 | PASS | focused_race.log reproduces GoalMet/Reason race; race_green.log after synchronized both writers/Planner snapshot:174 agent+204 server pass over3 repetitions, no race. Authentic usage/receipt tests preserved. |

## Known limits
- inherited startup-bind scheduler teardown race is out of approved repair scope; no full-suite success claimed.
- keyword first attempt transient Go toolchain/cache setup failure retained keyword-setup-failure.log; unchanged retry passed.
- Root reports unchanged Next16.4 advisory/build initial exit1 then retry0; dependency remediation is separate.
- Exact-head hosted CI, native Windows and live provider not exercised.

## Delivery
- Target: local only; coordinator owns browser QA and final evidence scoring.
- Authorized: yes, scoped user yes; later coordinator authorized narrow observed proof race repair.
