# Intent: 261025-pr40-review-repair

- Date: 2026-10-25
- Requested by: repository owner
- Source: approved parent conversation

## Bottom line
- **Changes:** finish the rebuilt PR #40, fix all observed verification failures and obtain fresh adversarial review before pushing and conditionally merging into dev.
- **Left out:** main promotion/release and live-provider calls; #46 is coordinator-owned and will follow the same conditional merge gates.
- **Needs you:** none; user explicitly authorized failure fixes, adversarial review, push and conditional merge.

## Request
- Integration update: dev advanced to7af06f1 while verification ran, introducing six shipped locales. Preserve those changes and complete this PR’s translated runtime/prompt/guide deltas before final verification; existing fix-and-merge authorization applies.
- Scope amendment: user explicitly selected “SDK 실패 7개까지 수정” after seeing all seven reproduced upstream failures. Repair those failures as part of this candidate; do not waive them for merge.
- Current authorization: “adversarial review if not issue push merge fix any failures”. This supersedes the earlier local-only delivery limit.
- “#40 rebuild intended changes on current dev; fix least-privilege test failure and translation-count conflict. #46 retain dev CI and add cancellation. Verify both locally, including browser smoke and preservation of current OpenCode behavior. Prepare reviewable changes; no push or merge.”
- Human answer to scope: “yes”.

## Understood as
- In scope: four intended commits aebea3e..9b04754, current dev f354c920, least-privilege regression repair, scheduler shutdown repair, cross-platform clipboard harness, minimal compatible dependency security updates, paired EN/KO docs, exact-candidate local/hosted validation and conditional dev merge.
- Out of scope: divergent historical PR aggregate, main promotion/release and live provider requests.
- O1: intended PR #40 functionality applies on latest dev without reverting OpenCode or host scope.
- O2: stock/runtime and engine proof integration pass under NOCREATEDB owning test role; isolation and cleanup remain verified.
- O3: complete backend build/test/vet and all three locale completeness checks pass; frontend/browser verification coordinated separately on exact ready commit.

- O4: shutdown joins scheduler work before DB closure; occupied-port and cancellation regressions pass repeatedly.
- O5: canonical browser suites use correct native shortcuts without assertion/timeout changes; frontend/adapter audits and clean builds pass after compatible dependency updates.
- O6: fresh independent review passes, seven required exact-head checks pass before each dev merge, and dev post-merge checks pass.
- O7: all seven reproduced Norma SDK failures corrected without weakening assertions: valid retry test initialization, window-relative pacing, bounded long-session context, learned overflow window, and positive tier-two regression; full SDK suite passes. Preserve transcript/raw records and public interfaces.

## Risks in this intent
- Scheduler lifecycle and dependency security changes are explicitly covered by “fix any failures”; preserve public contracts, scoped data and assertions.
- Guard reconstructed branch replacement with exact-SHA force-with-lease; stop if remote heads changed. Push/merge explicitly authorized. No production migration or runtime permission widening.

## Delivery
- Target: pr
- Note: update existing PR40 head fix/glm-agent-contracts from dedicated fix/pr40-review-repair; merge into dev only after gates.
- Authorized: yes — “adversarial review if not issue push merge fix any failures”.

## Blocking questions
- none

## Terms
- ✅ **NOCREATEDB** = owning PostgreSQL test role without database creation privilege; scripts/test-db.sh:6-11.
- ✅ **intended PR #40 changes** = aebea3e..9b04754, four commits, excluding divergent history; parent-approved scope.

## Clarity
| Area | State | How settled |
|---|---|---|
| Outcome | clear | O1-O3; Request |
| Scope | clear | Request and approved four-commit boundary |
| AS-IS | clear | F1 reproduced failure and F2 count conflict |
| TO-BE | clear | Request explicitly asks both repairs with current dev preserved |
| Success | clear | O1-O3 and approved local/browser checks |
| Constraints | clear | Current Request authorizes conditional push/merge; CONTRIBUTING disposable DB, language and check policies |

## Facts
- F1: Existing independent review reproduced SQLSTATE 42501 in four leaf cases with NOCREATEDB owner; /private/tmp/scopeweaver-pr-review-20261025-40-report/review.md. [verified: read review and helper source]
- F2: current dev contributes host scope key, while original PR adds four keys; conflict expected total 1987 to be verified by runtime catalog. [assumed: parent verified diff boundary; exact catalog check planned]
- F3: scripts/test-db.sh creates DB as owner and runs tests as usually-NOCREATEDB test role; existing db/chat_upgrade_test.go uses owned schema with search_path. [verified: source]

- F4: Current user explicitly authorizes adversarial review, fixes for failures, push and conditional merge. [verified: current chat]
- F5: Prior evidence has a reproduced scheduler DB-close failure, canonical macOS shortcut failures, and frontend/adapter dependency advisories. [verified: evidence.md and evidence-runtime.md before this amendment]
